# Build: the Pipeline Status agent (homeroom)

## What I want

A running status report on every active account, always current, sitting on the
homeroom page. The job it does: at any moment, someone internally asks "where's
your pipeline," and I read this out loud without preparing anything.

Brutally brief. Every line earns its place. But detailed enough that a reader
who has never heard of the account knows what's real and what isn't.

## Before you write anything

Read these first and build on what's there -- do not stand up a parallel data
layer:

- `src/app/room/page.tsx` and `room-client.tsx` -- homeroom, where this renders
- `src/lib/activity/read.ts` -- `fetchSecondRecords()`, `SecondRecord`, gems,
  `intentWarm`, `collisionFor`, `orgInboundHolder`
- `src/lib/activity/types.ts` -- `StagedRow`, `SliceMeta`
- `src/lib/book` -- `peos`, `csms`, `getPeo`
- `src/lib/book/contacts` -- `contactsFor`, `knownPeople`, `personKey`
- `src/lib/intel/` -- `extractDealIntel`, `digestFor`, `meetingRead`,
  `relationshipFor`, `people`
- `src/lib/dashboard/` -- `loadDashboard`, `DASH_NODES` (stages)
- `src/lib/today/overlay` -- notes, dispositions, todos, touches
- `src/lib/room/engine` -- `readDeal`, `meterRead`

Tell me what you found before you build, especially anything that already does
part of this.

## The record -- one per active account

Fields, in this order. Missing data renders as **Unknown**, never omitted and
never guessed. Unknowns are the point: a row of them tells me where discovery
has holes.

| Field | Source | Rule |
|---|---|---|
| **Account** | book | Name as it appears in the book |
| **Product(s)** | deal intel | EOR, Global Payroll, Contractor Management, AOR, Talent. Multiple allowed, comma-separated. Unknown if never stated |
| **CSM** | book | The assigned CSM. Distinct from contacts -- never merge the two |
| **Headcount in scope** | deal intel | Employees or contractors, with the unit named. "2 EEs (PR)" or "Unknown" |
| **My contacts** | activity + contacts | People *I* have corresponded with -- name, title where known. Derived from `StagedRow.w` (signature) and `.p` (correspondents), never from `.a` (logger). Must exclude the CSM and anyone internal to us |
| **Stage** | dashboard | Current `DASH_NODES` stage |
| **Close date** | deal intel | Date, or Unknown. Never invent one from stage |
| **Last meeting** | meeting read | Date and type. "Demo 8/27" |
| **Outcomes** | meeting read | Outcomes only, comma-separated. What was decided, agreed, learned or refused. Not topics, not what was shown, not sentiment. If nothing concluded, say "none recorded" |
| **Next step** | overlay + intel | One action, owner implied. If no next step exists that is the finding -- render "None set" and flag it |
| **Elsewhere at this account** | Second Record | See below |
| **Risk** | intel | One sentence, only if a real risk is evidenced. Otherwise omit the field entirely |

### "Elsewhere at this account"

One line on the most recent thing happening at the account **outside my deal**,
drawn from the latest Second Record run. Support cases, CSM traffic, renewal
motion, another product line, an escalation -- anything that means someone at
Infiniti-or-whoever is talking to someone at PrismHR who isn't me.

Use the non-sales lanes. Cite the date and what it was: "3 support cases wk of
8/18, benefits config." If the run classified the account support-traffic-only
with no sales motion, say so plainly.

This exists so I'm never surprised in front of leadership by something my own
company is doing at my account.

## Provenance rules -- non-negotiable

- Every field traces to a row, a note, or a book entry. No inference presented
  as fact.
- Where a value is derived rather than stated, mark it. A close date I named on
  a call and a close date the model guessed from stage age are not the same
  thing and must not look the same.
- `Assigned` on an activity row is who *logged* it, not who wrote it. Read
  `StagedRow.w` for authorship. Getting this wrong puts a CSM's name on my
  correspondence.
- Never merge a Second Record gem into deal intel silently -- gems are evidence,
  deal intel is claim.
- Money figures stay redacted per existing handling.

## Format

- Fixed-width label, value, newline. No prose paragraphs.
- Whole record fits a laptop screen without scrolling.
- Sort by whatever means "needs me most" -- go read `readDeal` / `meterRead` and
  use the existing signal rather than inventing a score.
- One-key copy of a single record, and of the whole report, as plain text I can
  paste into Slack or an email.

## Freshness

- Recompute on Second Record run completion and on overlay writes.
- Show the age of the underlying activity data on the report header. If the last
  run is older than `DROP_STALE_DAYS`, say the report is stale rather than
  rendering confidently wrong numbers.
- Never block homeroom render waiting on this. Progressive is fine.

## What "active" means

Define it from existing signal, not a new flag -- a stage that isn't closed, or
recent two-way activity. Show me the rule you picked and the resulting count
before you wire it up.

## Acceptance

- Every account in the report has a traceable source for every populated field.
- No field silently blank. Unknown is a value.
- I can read one record aloud in under 20 seconds.
- The whole report tells me, without me digging: what's real, what's stalled,
  what's missing, and what my own company is doing at my accounts.

## Build order

1. Report what you found in the existing libs and what already covers part of
   this.
2. Propose the "active" rule and the sort. Wait for me.
3. Build the data layer with the provenance marking.
4. Render on homeroom.
5. Copy-to-clipboard last.

Ask before adding a dependency. Ask before changing anything in
`src/lib/activity/` -- that pipeline is load-bearing.
